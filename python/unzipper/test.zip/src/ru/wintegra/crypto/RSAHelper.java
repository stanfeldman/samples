package ru.wintegra.crypto;

import org.w3c.dom.Element;
import org.xml.sax.SAXException;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.security.*;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.*;

public final class RSAHelper {
	public static String checkTokenAsString(byte[] tokenData, PublicKey publicKey, long ttl) {
		byte[] value = checkToken(tokenData, publicKey, ttl);
		return value == null ? null : (new String(value, utf8));
	}

	public static byte[] createToken(String tokenValue, PrivateKey privateKey) {
		return createToken(stringToBytes(tokenValue), privateKey);
	}

	public static byte[] checkToken(byte[] tokenData, PublicKey publicKey, long ttl) {
		long cur = currentTimeMillis();
		if (null == tokenData || 0 == tokenData.length) return null; // EMPTY
		try {
			DataInputStream dataInputStream = new DataInputStream(new ByteArrayInputStream(tokenData));
			long tokenTime = dataInputStream.readLong();
			if (ttl > 0 && (cur - tokenTime) > ttl) return null; // EXPIRED
			int valueSize = dataInputStream.readInt();
			byte[] value = new byte[valueSize];
			dataInputStream.readFully(value);
			int signatureSize = dataInputStream.readInt();
			byte[] signature = new byte[signatureSize];
			dataInputStream.readFully(signature);
			byte[] toCheck = new byte[8 + 4 + valueSize];
			dataInputStream.reset();
			dataInputStream.readFully(toCheck);
			return checkSignature(toCheck, signature, publicKey) ? value : null;
		} catch (EOFException e) {
			return null; // MAILFORMED
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public static byte[] createToken(byte[] tokenValue, PrivateKey privateKey) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
			dataOutputStream.writeLong(currentTimeMillis());  // eight bytes, high byte first.
			dataOutputStream.writeInt(tokenValue.length); // four bytes, high byte first.
			dataOutputStream.write(tokenValue);
			dataOutputStream.flush();
			byteArrayOutputStream.flush();
			byte[] signature = createSignature(byteArrayOutputStream.toByteArray(), privateKey);
			dataOutputStream.writeInt(signature.length);
			dataOutputStream.write(signature);
			dataOutputStream.flush();
			byteArrayOutputStream.flush();
			return byteArrayOutputStream.toByteArray();

		} catch (IOException ex) {
			throw new RuntimeException(ex.getMessage(), ex);
		}

	}

	private RSAHelper() {
	}

	private static final MessageDigest sha1;
	private static final MessageDigest md5;
	private static final Charset utf8;
	private static final KeyFactory kf;
	private static final KeyPairGenerator keyPairGenerator;
	private static final BASE64Encoder base64encoder;
	private static final BASE64Decoder base64decoder;


	static {
		try {
			sha1 = MessageDigest.getInstance("SHA1");
			md5 = MessageDigest.getInstance("MD5");
			keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		utf8 = Charset.forName("UTF-8");
		try {
			kf = KeyFactory.getInstance("RSA");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		base64decoder = new BASE64Decoder();
		base64encoder = new BASE64Encoder();
	}

	public static byte[] sha1(byte[] bytes) {
		return sha1.digest(bytes);
	}

	public static byte[] md5(byte[] bytes) {
		return md5.digest(bytes);
	}

	public static byte[] stringToBytes(String source) {
		return (source == null || source.isEmpty()) ? (new byte[]{0}) : source.getBytes(utf8);
	}

	public static long currentTimeMillis() {
		return System.currentTimeMillis();
	}

	public static byte[] createSignature(byte[] message, PrivateKey pk) {
		try {
			Signature instance = createSignatureInstance();
			instance.initSign(pk);
			instance.update(message);
			return instance.sign();
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (InvalidKeyException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (SignatureException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public static RSAPrivateCrtKey deserializePrivateKey(byte[] privateKey) {
		try {
			return (RSAPrivateCrtKey) kf.generatePrivate(new PKCS8EncodedKeySpec(privateKey));
		} catch (InvalidKeySpecException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	private static Signature createSignatureInstance() throws NoSuchAlgorithmException {
		return Signature.getInstance("SHA1withRSA");
	}

	public static boolean checkSignature(byte[] message, byte[] signature, PublicKey pk) {
		try {
			Signature instance = createSignatureInstance();
			instance.initVerify(pk);
			instance.update(message);
			return instance.verify(signature);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (InvalidKeyException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (SignatureException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public static RSAPublicKey deserializePublicKey(byte[] publicKey) {
		try {
			return (RSAPublicKey) kf.generatePublic(new X509EncodedKeySpec(publicKey));
		} catch (InvalidKeySpecException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public static String toBase64String(byte[] bytes) {
		return base64encoder.encode(bytes).replace("\n", "").replace("\r", "");
	}

	public static byte[] fromBase64String(String s) {
		try {
			return base64decoder.decodeBuffer(s);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public static KeyPair generateKeyPair() {
		return keyPairGenerator.generateKeyPair();
	}

	public static RSAPublicKey publicKeyFromPrivateKey(PrivateKey privateKey) {
		try {
			RSAPrivateCrtKey privateCrtKey = (RSAPrivateCrtKey) privateKey;
			return (RSAPublicKey) kf.generatePublic(new RSAPublicKeySpec(privateCrtKey.getModulus(), privateCrtKey.getPublicExponent()));
		} catch (InvalidKeySpecException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	private static byte[] stripLeadingZeroes(byte[] a) {
		int lastZero = -1;
		for (int i = 0; i < a.length; i++) {
			if (a[i] == 0) {
				lastZero = i;
			} else {
				break;
			}
		}
		lastZero++;
		byte[] result = new byte[a.length - lastZero];
		System.arraycopy(a, lastZero, result, 0, result.length);
		return result;
	}


	public static String exportKeyToXmlString(Key rsaKey, boolean includePrivateKey) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("<RSAKeyValue><Modulus>");
		if (rsaKey instanceof RSAPublicKey) {
			RSAPublicKey k = (RSAPublicKey) rsaKey;
			stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getModulus().toByteArray())));
			stringBuilder.append("</Modulus><Exponent>");
			stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getPublicExponent().toByteArray())));
			stringBuilder.append("</Exponent>");
		} else {
			RSAPrivateCrtKey k = (RSAPrivateCrtKey) rsaKey;
			stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getModulus().toByteArray())));
			stringBuilder.append("</Modulus><Exponent>");
			stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getPublicExponent().toByteArray())));
			stringBuilder.append("</Exponent>");
			if (includePrivateKey) {
				stringBuilder.append("<P>");
				stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getPrimeP().toByteArray())));
				stringBuilder.append("</P><Q>");
				stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getPrimeQ().toByteArray())));
				stringBuilder.append("</Q><DP>");
				stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getPrimeExponentP().toByteArray())));
				stringBuilder.append("</DP><DQ>");
				stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getPrimeExponentQ().toByteArray())));
				stringBuilder.append("</DQ><InverseQ>");
				stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getCrtCoefficient().toByteArray())));
				stringBuilder.append("</InverseQ><D>");
				stringBuilder.append(base64encoder.encode(stripLeadingZeroes(k.getPrivateExponent().toByteArray())));
				stringBuilder.append("</D>");
			}
		}
		stringBuilder.append("</RSAKeyValue>");
		return stringBuilder.toString();
	}

	private static BigInteger read(Element root, String tagName) throws IOException {
        byte[] bytes = base64decoder.decodeBuffer(root.getElementsByTagName(tagName).item(0).getTextContent());
        int len = bytes.length;
        byte[] a2 = new byte[len+1];
        System.arraycopy(bytes,0,a2,1,len);
        a2[0]=0;
		return new BigInteger(a2);
	}

	public static Key importKeyFromXmlString(String xmlString) {
		ByteArrayInputStream bos = new ByteArrayInputStream(xmlString.getBytes(utf8));
		try {
			org.w3c.dom.Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(bos);
			Element root = doc.getDocumentElement();
			if (root.getElementsByTagName("D").getLength() != 0) {
				return kf.generatePrivate(new RSAPrivateCrtKeySpec(read(root, "Modulus"), read(root, "Exponent"), read(root, "D"), read(root, "P"), read(root, "Q"), read(root, "DP"), read(root, "DQ"), read(root, "InverseQ")));
			} else {
				return kf.generatePublic(new RSAPublicKeySpec(read(root, "Modulus"), read(root, "Exponent")));
			}
		} catch (SAXException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (InvalidKeySpecException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public static byte[] serializeKey(Key key) {
		return key.getEncoded();
	}

}
