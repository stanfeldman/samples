package ru.wintegra.dvfu.sso.servlet;

import ru.wintegra.crypto.RSAHelper;
import ru.wintegra.dvfu.sso.Configuration;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.IOException;
import java.security.Principal;
import java.security.PublicKey;
import java.util.Enumeration;
import java.util.Properties;

/**
 * User: dimzon
 * Date: 09.11.11
 * Time: 2:37
 */
public final class SSOFilter implements Filter {
    private PublicKey publicKey;
    private long ttl;
    private String headerName;

    public SSOFilter() {
    }

    public void init(FilterConfig filterConfig) throws ServletException {
        Properties properties = Configuration.getProperties();
        Enumeration<String> parameterNames = filterConfig.getInitParameterNames();
        while (parameterNames.hasMoreElements()) {
            String parameterName = parameterNames.nextElement();
            properties.setProperty(parameterName, filterConfig.getInitParameter(parameterName));
        }
        Configuration configuration = new Configuration(properties);
        ttl = configuration.ttl();
        publicKey = (PublicKey) RSAHelper.importKeyFromXmlString(configuration.publicKeyXML());
        headerName = configuration.httpHeader();
    }

    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        String headerValue = request.getHeader(headerName);
        if (null != headerValue && !headerValue.isEmpty()) {
            byte[] userToken = RSAHelper.fromBase64String(headerValue);
            final String login = RSAHelper.checkTokenAsString(userToken, publicKey, ttl);
            if (login != null && !login.isEmpty()) {
                servletRequest = new HttpServletRequestWrapper(request) {
                    @Override
                    public String getAuthType() {
                        return BASIC_AUTH;
                    }

                    @Override
                    public String getRemoteUser() {
                        return login;
                    }

                    @Override
                    public Principal getUserPrincipal() {
                        return new Principal() {
                            public String getName() {
                                return login;
                            }

                            @Override
                            public int hashCode() {
                                return login.hashCode();
                            }

                            @Override
                            public boolean equals(Object o) {
                                return (o instanceof Principal) && login.equals(((Principal) o).getName());
                            }

                            @Override
                            public String toString() {
                                return getName();
                            }
                        };

                    }
                };
            }
        }
        filterChain.doFilter(servletRequest, servletResponse);

    }

    public void destroy() {
    }
}
