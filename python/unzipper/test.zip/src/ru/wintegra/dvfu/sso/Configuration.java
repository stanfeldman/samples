package ru.wintegra.dvfu.sso;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * User: dimzon
 * Date: 09.11.11
 * Time: 2:54
 */
public final class Configuration {
	public static final String TTL_KEY = "ru.wintegra.dvfu.sso.ttl";
	public static final String PUBLIC_KEY_KEY = "ru.wintegra.dvfu.sso.publicKey";
	public static final String SSO_ENV_KEY = "ru.wintegra.dvfu.sso.enviromentKey";
	public static final String SSO_HTTP_HEADER_KEY="ru.wintegra.dvfu.sso.httpHeader";

	private static Properties mergeProperties(Properties source, Properties target) {
		for (String propertyName : source.stringPropertyNames())
			target.setProperty(propertyName, source.getProperty(propertyName));
		return target;
	}

	public static Configuration getDefaults() {
		return new Configuration(getProperties());
	}

	public static Properties getProperties() {
		InputStream inputStream = Configuration.class.getResourceAsStream("sso.properties");
		Properties properties = loadProperties(inputStream);
		String filePath = System.getenv(properties.getProperty(SSO_ENV_KEY));
		if (filePath != null && !filePath.isEmpty()) try {
			properties.remove(SSO_ENV_KEY);
			properties = mergeProperties(loadProperties(new FileInputStream(filePath)), properties);
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		properties = mergeProperties(System.getProperties(), properties);
		return properties;
	}

	private static Properties loadProperties(InputStream inputStream) {
		Properties properties = new Properties();
		try {
			properties.load(inputStream);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) {
			}
		}
		return properties;
	}

	private Properties properties;
	public Properties properties(){
		return properties;
	}

	public long ttl() {
		return Long.parseLong(properties.getProperty(TTL_KEY));
	}

	public String publicKeyXML() {
		return properties.getProperty(PUBLIC_KEY_KEY);
	}

	public String httpHeader(){
		return properties.getProperty(SSO_HTTP_HEADER_KEY);
	}

	public Configuration(Properties properties) {
		this.properties = properties;
	}
}
