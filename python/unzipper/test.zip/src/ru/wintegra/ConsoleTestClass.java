package ru.wintegra;

import ru.wintegra.crypto.RSAHelper;
import ru.wintegra.dvfu.sso.Configuration;

import java.security.KeyPair;
import java.security.PublicKey;

/**
 * Created by IntelliJ IDEA.
 * User: DAlexandrov
 * Date: 08.11.11
 * Time: 13:52
 * To change this template use File | Settings | File Templates.
 */
public final class ConsoleTestClass {
    private static String signature2String(byte[] bytes) {
        StringBuilder string = new StringBuilder();
        for (byte b : bytes) {
            String hexString = Integer.toHexString(0x00FF & b);
            string.append(hexString.length() == 1 ? "0" + hexString : hexString);
        }
        return string.toString();
    }
//
//    public static byte[] sha1(byte[] signature) throws NoSuchAlgorithmException {
//        return RSAHelper.sha1(signature);
//    }
//
//    public static byte[] md5(byte[] signature) throws NoSuchAlgorithmException {
//        return RSAHelper.md5(signature);
//    }
//
//
//    public static byte[] getSignature(byte[] message, byte[] privateKey) {
//        return RSAHelper.createSignature(message, privateKey);
//    }
//
//    private static byte[] compressSignature(byte[] sign) throws IOException {
//        ByteArrayOutputStream byteArrayInputStream = new ByteArrayOutputStream();
//        GZIPOutputStream gzipOutputStream = new GZIPOutputStream(byteArrayInputStream){{def.setLevel(Deflater.BEST_COMPRESSION);}};
//        gzipOutputStream.write(sign);
//        gzipOutputStream.close();
//        byteArrayInputStream.close();
//        return byteArrayInputStream.toByteArray();
//    }

    public static void main(String args[]) {
		KeyPair keys = RSAHelper.generateKeyPair();

		String currentUser = "dalexandrov@wintegra-software.lan";
		byte[] token = RSAHelper.createToken(currentUser, keys.getPrivate());
		System.out.println(token.length);
		System.out.println(RSAHelper.toBase64String(token));

        PublicKey kk = (PublicKey) RSAHelper.importKeyFromXmlString(RSAHelper.exportKeyToXmlString(keys.getPublic(), false));

		String retVal = RSAHelper.checkTokenAsString(token, kk,1000);
		System.out.println(retVal );
		System.out.println(currentUser.equals(retVal));
		//System.out.println(Arrays.toString(RSAHelper.serializeKey(keys.getPublic())));
		System.out.println(RSAHelper.exportKeyToXmlString(keys.getPrivate(),false));

		System.out.println(Configuration.getDefaults().publicKeyXML());


        final String test = "AAABM4jKpP4AAAASZGltem9uQHdpbnRlZ3JhLnJ1AAAAgHmgmaxQztICPVlhm+ylfZ4w5+w7kLkwf3+4" +
                "NqsJte4s+BMSE0TGxrzdeHMeZrRAugkI4+uRc+c0msSYRXD7Xu29oM+tiAHfThfozYCOYqvSco9qdc1n" +
                "h9dB1UCPjufGnvPP35EwuVEko4uaqDAkxxEz3zzJyQ7kCGRBMDhIp0J9";
        byte[] data = RSAHelper.fromBase64String(test);
        PublicKey k2 = (PublicKey) RSAHelper.importKeyFromXmlString(Configuration.getDefaults().publicKeyXML());
        System.out.println(RSAHelper.checkTokenAsString(data, k2, 1000*60*300));

        byte[] msg =  RSAHelper.stringToBytes("foo");
        byte[] sign = RSAHelper.fromBase64String("hEf25U3SuCSjuN6lwApA2hz5W2WQnhkpyPB6BJEJ9jGt35tcW77Vh84bfnrICUyXDjPOGzYlh8Sstv0v" +
                "/p5WDJc6fgmduth/dsUu+Mpl2xkvsqtCXisXiaNr/iGw9GxDdDwcWgaekhskGP0A8lVEbkSfrVj1ofF6" +
                "TizFmtjo6sM=");
        System.out.print(RSAHelper.checkSignature(msg,sign,k2));


//        try {                                 false
//            String plaintext = "This is the message being signed";
//            RSAHelper keys = RSAHelper.generateKeyPair();
//            byte[] message = RSAHelper.stringToBytes(plaintext);
//            byte[] signature = RSAHelper.createSignature(message, keys.getPrivateKey());
//            System.out.println(keys.getPrivateKey().length);
//            System.out.println(signature2String(keys.getPrivateKey()));
//            System.out.println(keys.getPublicKey().length);
//            System.out.println(signature2String(keys.getPublicKey()));
//
//            System.out.println(signature.length);
//            System.out.println(signature2String(signature));
//            System.out.println(RSAHelper.checkSignature(message, signature, keys.getPublicKey()));
//
//
//            System.out.println(RSAHelper.checkSignature(plaintext, RSAHelper.toBase64String(signature), RSAHelper.keyToBase64(keys.getPublicKey())));
//
//            message[4]= (byte) (message[4]-5);
//            System.out.println(RSAHelper.checkSignature(message, signature, keys.getPublicKey()));
//
//
//            System.out.println(signature.length);
//            System.out.println(signature2String(signature));
//            String base64 = (new BASE64Encoder()).encode(signature).replace("\n","").replace("\r","");
//            System.out.println(base64.length());
//            System.out.println(base64);
//
//
//            System.out.println(System.currentTimeMillis());
//            System.out.println((new Date()).getTime());
//
//            System.out.println(RSAHelper.exportPrivateKeyToXmlString(keys.getPrivateKey(), true));
//
//            byte[] newPrivate =  RSAHelper.importPrivateKeyFromXmlString(RSAHelper.exportPrivateKeyToXmlString(keys.getPrivateKey(), true));
//            byte[] newPrivate1 =  RSAHelper.importPrivateKeyFromXmlString(RSAHelper.exportPrivateKeyToXmlString(newPrivate, true));
//            System.out.println(RSAHelper.keyToBase64(keys.getPrivateKey()));
//            System.out.println(RSAHelper.keyToBase64(newPrivate));
//            System.out.println(RSAHelper.keyToBase64(newPrivate1));
//
//            signature = RSAHelper.createSignature(message, keys.getPrivateKey());
//            System.out.println(signature.length);
//            System.out.println(signature2String(signature));
//
//            signature = RSAHelper.createSignature(message, newPrivate);
//            System.out.println(signature.length);
//            System.out.println(signature2String(signature));
//
//            System.out.println(RSAHelper.checkSignature(message, signature, keys.getPublicKey()));
//            System.out.println(RSAHelper.checkSignature(message, signature, RSAHelper.publicKeyFromPrivateKey(newPrivate1)));
//
//
//        } catch (Exception ex) {
//            throw new RuntimeException(ex.getMessage(), ex);
//        }
    }
}
